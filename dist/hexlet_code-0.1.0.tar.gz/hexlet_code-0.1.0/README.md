### Hexlet tests and linter status:
[![Actions Status](https://github.com/mur-misha/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/mur-misha/python-project-49/actions)

<a 
href="https://codeclimate.com/github/mur-misha/python-project-49/maintainability"><img 
src="https://api.codeclimate.com/v1/badges/827a3117e7c795648e01/maintainability" 
/></a>

https://asciinema.org/connect/e014fecc-a9af-4089-9168-a64b75be4225
