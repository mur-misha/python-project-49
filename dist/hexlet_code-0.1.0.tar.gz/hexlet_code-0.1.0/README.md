### Hexlet tests and linter status:
[![Actions Status](https://github.com/mur-misha/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/mur-misha/python-project-49/actions)

<a 
href="https://codeclimate.com/github/mur-misha/python-project-49/maintainability"><img 
src="https://api.codeclimate.com/v1/badges/827a3117e7c795648e01/maintainability" 
/></a>

<a href="https://asciinema.org/a/u0dzgPmnTMMqsZPD633PY1H8B" target="_blank"><img 
src="https://asciinema.org/a/u0dzgPmnTMMqsZPD633PY1H8B.svg" /></a>

<a href="https://asciinema.org/a/XzAud3dpXFlVi0d0GkmNxwUCB" target="_blank"><img 
src="https://asciinema.org/a/XzAud3dpXFlVi0d0GkmNxwUCB.svg" /></a>

<a href="https://asciinema.org/a/NUKd7yDQ2G3xyAQLOhU3yUzN7" target="_blank"><img 
src="https://asciinema.org/a/NUKd7yDQ2G3xyAQLOhU3yUzN7.svg" /></a>

[![asciicast](https://asciinema.org/a/YNLNcQIGHdtB3UKowudWuyeEj.svg)](https://asciinema.org/a/YNLNcQIGHdtB3UKowudWuyeEj)
